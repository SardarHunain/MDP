import React, { useState } from 'react';

import { View, Button, Text, TextInput } from 'react-native';


const Home = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  return (
    <View>
      <Text style={{ fontSize: 30, textAlign: 'center', fontWeight: 'bold' }}>
        Home Screen
      </Text>
      <TextInput
        placeholder="Email"
        onChangeText={setEmail}
        style={{ borderWidth: 2, padding: 5 }}
      />
      <TextInput
        placeholder="Name"
        onChangeText={setName}
        style={{ borderWidth: 2, padding: 5 }}
      />
      <Button
        title="Move to Profile Screen"
        onPress={() =>
          navigation.navigate('Profile', { email: email, name: name })
        }
      />
    </View>
  );
};

const Profile = ({  route }) => {
  

  return (
    <View>
      <Text style={{ fontSize: 30, textAlign: 'center', fontWeight: 'bold' }}>
        Profile Screen
      </Text>

      <Text style={{ fontSize: 15, textAlign: 'center', fontWeight: 'bold' }}>
        Email:{route.params.email}
      </Text>
      <Text style={{ fontSize: 15, textAlign: 'center', fontWeight: 'bold' }}>
        Name:{route.params.name}
      </Text>

      <Button
        title="Move to Home Screen"
        onPress={() =>
          navigation.navigate('Home')
        }
      />
    </View>
  );
};

const App = () => {
  return (
    <View>
      <Home />
      <Profile/>
    </View>
  );
};

export default App;
